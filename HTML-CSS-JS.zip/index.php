<?php
include 'server/database.php';

$sql = "SELECT title, description, filename, thumbnail FROM videos ORDER BY upload_date DESC";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YourTube</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
    <header>
        <h1>YourTube</h1>
    </header>
    <main>
        <h2>Trending Videos</h2>
        <div class="video-grid">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="video">';
                    echo '<img src="uploads/thumbnails/' . $row["thumbnail"] . '" alt="Video Thumbnail">';
                    echo '<h3>' . $row["title"] . '</h3>';
                    echo '<p>' . $row["description"] . '</p>';
                    echo '<video width="320" height="240" controls>
                            <source src="uploads/videos/' . $row["filename"] . '" type="video/mp4">
                          Your browser does not support the video tag.
                          </video>';
                    echo '</div>';
                }
            } else {
                echo "No videos found.";
            }
            $conn->close();
            ?>
        </div>
    </main>
</body>
</html>

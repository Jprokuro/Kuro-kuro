<?php
include 'server/database.php';

$sql = "SELECT id, title, thumbnail FROM videos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="video">';
        echo '<img src="uploads/thumbnails/' . $row["thumbnail"] . '" alt="Video Thumbnail">';
        echo '<h3>' . $row["title"] . '</h3>';
        echo '</div>';
    }
} else {
    echo "0 results";
}
$conn->close();
?>

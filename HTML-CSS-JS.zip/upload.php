<?php
include 'database.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['video'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Directory to save uploaded videos
    $target_dir = "../uploads/videos/";
    $target_thumb_dir = "../uploads/thumbnails/";

    // Generate unique filename
    $videoFileType = strtolower(pathinfo($_FILES["video"]["name"], PATHINFO_EXTENSION));
    $videoFileName = uniqid() . '.' . $videoFileType;
    $target_file = $target_dir . $videoFileName;

    // Allowed video formats
    $valid_formats = array("mp4", "avi", "mov", "wmv");

    if (in_array($videoFileType, $valid_formats)) {
        if (move_uploaded_file($_FILES["video"]["tmp_name"], $target_file)) {
            // Generate a thumbnail for the video (optional, requires ffmpeg)
            $thumbnail = uniqid() . ".jpg";
            $thumbnail_path = $target_thumb_dir . $thumbnail;
            $ffmpeg = "/usr/bin/ffmpeg"; // Adjust path as necessary
            $cmd = "$ffmpeg -i $target_file -ss 00:00:02.000 -vframes 1 $thumbnail_path";
            shell_exec($cmd);

            // Insert video details into the database
            $stmt = $conn->prepare("INSERT INTO videos (title, description, filename, thumbnail) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $title, $description, $videoFileName, $thumbnail);

            if ($stmt->execute()) {
                echo "The file " . htmlspecialchars(basename($_FILES["video"]["name"])) . " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }

            $stmt->close();
        } else {
            echo "Sorry, there was an error moving the uploaded file.";
        }
    } else {
        echo "Sorry, only MP4, AVI, MOV, & WMV files are allowed.";
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>
